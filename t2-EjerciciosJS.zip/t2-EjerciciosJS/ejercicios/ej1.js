// valor 1
alert("Empieza el ejercicio 1");
// Crea 2 variables numéricas


// Imprime un alert con la suma de ambas.


// Imprime un alert con la resta de ambas.


// Imprime un alert con el producto de ambas.


// Cambia el valor de la segunda variable a 0.


// Imprime la division de ambas.

