// valor 1
alert("Empieza el ejercicio 2");
// Crea una variable numérica.


// Crea una cadena de texto con el valor 25.


// Imprime la suma de ambas mediante un alert.


// Crea una variable booleana.


// Imprime en la consola la suma de las 3 variables.


